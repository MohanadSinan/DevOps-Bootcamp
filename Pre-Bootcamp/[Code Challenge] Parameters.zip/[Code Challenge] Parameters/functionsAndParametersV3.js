function greet(name) {
    if (name == "Count Dooku") {
        console.log("I'm coming for you, Dooku!");
    } else {
        console.log("Good day, ", name);
    }
}
greet("Muhannad")
greet("Count Dooku")