function greet(name) {
    console.log("Good day, ", name);
}
greet("Muhannad")